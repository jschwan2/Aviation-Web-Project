from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponse
from .models import *
import re
from selenium import webdriver
import datetime
import time
import argparse
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pytaf
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from io import BytesIO
import base64
from pylab import *
import PIL, PIL.Image
from io import BytesIO
from PIL import Image, ImageDraw,ImageFont
 

#Function to execute and obtain relevant information for .html
def aviation_view(request):
	all_metar_items = Metar_Item.objects.all() #obtaining all metar objects saved in database
	all_taf_items = Taf_Item.objects.all() #obtaining all taf objects saved in database
	all_searched_items = Searched_Item.objects.all() #obtaining all search objects saved in database
	all_feedback_items = Feedback_Item.objects.all() #obtaining all feedback objects saved in database


	#Finds most recent departure information from user
	for i in range(len(all_metar_items)):
		num = len(all_metar_items)-(i+1)
		if all_metar_items[num].search_type == "  DEPARTURE":
			print("Check1")
			wind_extractor(all_metar_items[num].metar, all_taf_items[num].taf) #gets relevant wind information
			showdepimage(request) #plots departure image
			print(i)
			break

	#Finds most recent arrival information from user
	for i in range(len(all_metar_items)):
		num = len(all_metar_items)-(i+1)
		if all_metar_items[num].search_type == "  ARRIVAL":
			print("Check1")
			wind_extractor(all_metar_items[num].metar, all_taf_items[num].taf) #gets relevant wind information
			showarrimage(request) #plots arrival image
			print(i)
			break


	all_aviation_items = {} #Dictionary holding relevant info for .htmls to access

	#Loop to append/add relevant information to all_aviation_items
	for i in range(len(all_metar_items)):
		current_num = len(all_metar_items)-(i+1)
		all_aviation_items[i] = {"airport_id": all_metar_items[current_num].airport_id,
								"metar": all_metar_items[current_num].metar,
								"metar_decoded": all_metar_items[current_num].metar_decoded,
								"taf": all_taf_items[current_num].taf,
								"taf_decoded": all_taf_items[current_num].taf_decoded,
								"date_searched": all_searched_items[current_num].date_searched,
								"search_type": all_metar_items[current_num].search_type,
								"feedback": all_feedback_items[current_num].feedback,
								"id": all_taf_items[current_num].id}					
	return render(request, "aviation_app.html", {"all_aviation_items":all_aviation_items}) #rendering information for .html
	

#Wind extraction function to retrieve relevant information from
#metar and taf necessary to plot
def wind_extractor(metar, taf):
	#pattern for regex to obtain relevant wind data
	wind_pattern = """
					(?<= \s )
					(?P<direction> (\d{3}|VRB)) # Three digits or VRB
					(?P<speed> \d{2,3})         # Next two digits are speed in knots
					(G(?P<gust> \d{2,3})){0,1}  # Optional gust data (Gxx)
					(?P<unit> KT|MPS)           # Knots or meters per second
					(?= \s|$ )
					"""

	#getting pattern extractinos from metar and taf
	wind = re.findall(wind_pattern, metar+taf, re.VERBOSE)

	wind_speeds = []
	wind_directions =[]

	#appending necessary info to speed and direction arrays in correct format
	if wind:
		for i in wind:
			wind_directions.append(i[1] + " degrees")
			wind_speeds.append(i[2])


	#extracting time associaated with each wind prediction
	times = re.findall(r'\D(\d{6})\D', metar+taf)

	#Arrays to be retrieved for plotting
	x = []
	y = []
	labels = []
	placed = False 

	#Loop to append wind information to appropriate arrays with labels
	if wind_directions:
		#Sorts arrays by respective time report.
		for i in range(len(times)-1):
			#checks if singular metar wind report has been placed
			if (int(times[0]) < int(times[i+1])) and (placed == False):
				placed = True
				x.append(times[0])
				y.append(wind_speeds[0])
				labels.append(wind_directions[0])
				x.append(times[i+1])
				y.append(wind_speeds[i+1])
				labels.append(wind_directions[i+1])
			else:
				x.append(times[i+1])
				y.append(wind_speeds[i+1])
				labels.append(wind_directions[i+1])

		#Submitting relevant plot information
		ploty = Plot_Item(x =",".join(x) , 
						y = ",".join(y), 
						label = ",".join(labels))
		ploty.save() #saving to database


#Function to make and store departure wind visualization image
def showdepimage(request):
	#obtaining most recent data to plot
	all_plot_items = Plot_Item.objects.all()

	#stores relevant information of approriate arrays
	x = all_plot_items[len(all_plot_items)-1].x
	y = all_plot_items[len(all_plot_items)-1].y
	label = all_plot_items[len(all_plot_items)-1].label
	xs = x.split(",")
	ys = y.split(",")
	labels = label.split(",")

	#creates multidimensional array to pair associated data
	wind_array =[]
	for i in range(len(labels)):
		 wind_array.append([labels[i], xs[i], ys[i]])


	try:
		ys = [int(i) for i in ys] #converts to plottable int
		plt.plot(xs, ys, '--') #makes dashed line from point to point
		for point in wind_array:
			if point[0] != '': #if not blank info make scatter plot
			    pointRefNumber = point[0]
			    xPoint = point[1]
			    yPoint =  int(point[2])
			    plt.scatter(xPoint, yPoint)		   
			    plt.annotate(pointRefNumber, (xPoint, yPoint), fontsize=10)
		plt.savefig("media/departure_image.png") #saves in image media
		plt.close()
		print('done dep save')
	except: #If array doesn't contain appropriate data
		#Creates image to display "Insufficient Airport Data To Plot" 
		img = Image.new('RGB', (500, 70), color = (255, 255, 255))
		fnt = ImageFont.truetype('/Library/Fonts/Arial.ttf', 25)
		d = ImageDraw.Draw(img)
		d.text((0,20), "Insufficient Airport Data To Plot", font=fnt, fill=(0,0,0))
		img.save("media/departure_image.png")
		print("You suck dep")

	time.sleep(1) #allows time to finish process
	return #returns blank

#TODO: Attempt to remove
#Duplicate of much of departure image function
#Function to make and store arrival wind visualization image
def showarrimage(request):
	all_plot_items = Plot_Item.objects.all()
	x = all_plot_items[len(all_plot_items)-1].x
	y = all_plot_items[len(all_plot_items)-1].y
	label = all_plot_items[len(all_plot_items)-1].label
	xs = x.split(",")
	ys = y.split(",")
	labels = label.split(",")

	wind_array =[]
	for i in range(len(labels)):
		 wind_array.append([labels[i], xs[i], ys[i]])

	try:
		ys = [int(i) for i in ys]
		plt.plot(xs, ys, '--')
		for point in wind_array:
			if point[0] != '':
			    pointRefNumber = point[0]
			    xPoint = point[1]
			    yPoint =  int(point[2])
			    plt.scatter(xPoint, yPoint)		   
			    plt.annotate(pointRefNumber, (xPoint, yPoint), fontsize=10)

		print(os.getcwd())
		plt.savefig("media/aviation_proj/arrival_image.png")
		plt.close()
		print('done arr save')
	except:
		img = Image.new('RGB', (500, 70), color = (255, 255, 255))
		fnt = ImageFont.truetype('/Library/Fonts/Arial.ttf', 25)
		d = ImageDraw.Draw(img)
		d.text((0,20), "Insufficient Airport Data To Plot", font=fnt, fill=(0,0,0))
		img.save("media/aviation_proj/arrival_image.png")
		print("You suck arr")

	buffer = BytesIO()
	time.sleep(1)
	return HttpResponse(buffer.getvalue(), content_type="image/png")


#removes all related data to specific id from database.
def delete_item(request, item_id):
	item_to_delete = Metar_Item.objects.get(id=item_id)
	item_to_delete.delete()
	item_to_delete = Taf_Item.objects.get(id=item_id)
	item_to_delete.delete()
	item_to_delete = Feedback_Item.objects.get(id=item_id)
	item_to_delete.delete()
	item_to_delete = Searched_Item.objects.get(id=item_id)
	item_to_delete.delete()
	return HttpResponseRedirect("/")

#TODO: IS NECESSARY?
#Function to add departure item when user makes search
def add_departure_item(request):
	uni_add(request, "DEPARTURE")
	return HttpResponseRedirect("/")

#TODO: IS NECESSARY?
#Function to add arrival item when user makes search
def add_arrival_item(request):
	uni_add(request, "ARRIVAL")
	return HttpResponseRedirect("/")

#Function to allow user to submit feedback to site admin
def submit_feedback(request):
	metar_to_save = Metar_Item(search_type = "  FEEDBACK")
	metar_to_save.save()
	taf_to_save = Taf_Item(search_type = "  FEEDBACK")
	taf_to_save.save()
	search_to_save = Searched_Item(date_searched = str(datetime.datetime.utcnow()))
	search_to_save.save()
	feedback = Feedback_Item(feedback = request.POST.get('message'))
	feedback.save()
	return HttpResponseRedirect("/")

#function to add either arrival or departure information to the database
def uni_add(request, flight_type):
	airport_id = request.POST.get('airport_id') #sets airport id to save and search

	#initializes blank items to prevent errors
	metar = ""
	metar_decoded = ""
	taf = ""
	taf_decoded = ""

	#setting up chrome driver and headless parameter for selenium to use
	options = webdriver.ChromeOptions() 
	options.add_argument("start-maximized")
	options.add_argument("--disable-extensions")
	options.add_argument('disable-infobars')
	options.add_argument("--headless")  
	driver = webdriver.Chrome(options=options, executable_path=r'/Users/jonoschwan/Documents/chromedriver')
	
	#Obtaining metar information for specific airport
	driver.get("https://www.aviationweather.gov/metar/data?ids=" + airport_id + "&format=raw&date=&hours=0")
	
	#Obtaining metar information from site
	metarid_element = driver.find_elements_by_xpath('/html/body/div[1]/div[2]/div/div[2]/code')

	#attempts to decode and store decode metar airport information
	try:
		metary = pytaf.TAF(metarid_element[0].text)
		decoder = pytaf.Decoder(metary)
		metar = metarid_element[0].text
		metar_decoded = decoder.decode_taf()

		driver.get("https://www.aviationweather.gov/taf/data?ids=" + airport_id + "&format=raw&date=&submit=Get+TAF+data")
		tafid_element = driver.find_elements_by_xpath('/html/body/div[1]/div[2]/div/div[2]/code')
	except: #if invalid airport information entered
		metar = "UNAVAILABLE FOR AIRPORT ID PROVIDED"
		metar_decoded = "UNAVAILABLE FOR AIRPORT ID PROVIDED"

	#attempts to decode and store decode taf airport information
	try:
		tafy = pytaf.TAF(tafid_element[0].text)
		decoder = pytaf.Decoder(tafy)
		taf = tafid_element[0].text
		taf_decoded =  decoder.decode_taf()
	except: #if invalid airport information entered or airport does not provide taf
		taf = "UNAVAILABLE FOR AIRPORT ID PROVIDED"
		taf_decoded = "UNAVAILABLE FOR AIRPORT ID PROVIDED"

	#Creates metar with all class items to be saved
	metar_to_save = Metar_Item(search_type = "  " + flight_type,
		airport_id = "  " + airport_id.upper(), 
		metar = "  " + metar,
		metar_decoded = "  " + metar_decoded)
	metar_to_save.save() #saves metara item

	#Creates taf with all class items to be saved
	taf_to_save = Taf_Item(search_type = "  " + flight_type,
		airport_id = "  " + airport_id.upper(),
		taf = "  " + taf,
		taf_decoded = "  " + taf_decoded)
	taf_to_save.save() #saves taf item

	#Creates search object with associated information
	search_to_save = Searched_Item(searched_airport_id = "  " + airport_id.upper(),
									date_searched = str(datetime.datetime.utcnow()))
	search_to_save.save() #saves search item

	feedback = Feedback_Item() #creates blank feedback item
	feedback.save() #saves blank feedback item

	driver.quit() #quits driver necessaary to search web
