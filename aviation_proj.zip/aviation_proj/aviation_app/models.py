from django.db import models

#Metar class holding the searched time's metar information
class Metar_Item(models.Model):
	search_type = models.CharField(max_length=140, default='BLANK')
	airport_id = models.TextField()
	metar = models.CharField(max_length=140, default='BLANK')
	metar_decoded = models.CharField(max_length=140, default='BLANK')


#Taf class holding the searched time's taf information
class Taf_Item(models.Model):
	search_type = models.CharField(max_length=140, default='BLANK')
	airport_id = models.TextField()
	taf = models.TextField()
	taf_decoded = models.TextField()
	photo = models.ImageField(upload_to="gallery",default='BLANK')


#Plot class holding the information from both metar and taf necessary to plot
class Plot_Item(models.Model):
	x = models.CharField(max_length=10000, default='BLANK')
	y = models.CharField(max_length=10000, default='BLANK')
	label = models.CharField(max_length=10000, default='BLANK')


#Warning item if associated with flight path
class Warning_Item(models.Model):
	warning = models.TextField()


#Class storing searched item and time for each submission by user
class Searched_Item(models.Model):
	searched_airport_id = models.TextField()
	date_searched = models.CharField(max_length=140, default='BLANK')

#Class storing relevant update information that users must see
class Update_Post(models.Model):
	update_post = models.TextField()

#Class storing feedback given to admin by a user
class Feedback_Item(models.Model):
	feedback = models.CharField(max_length=10000, default='BLANK')
