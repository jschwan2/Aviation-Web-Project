from django.apps import AppConfig


class AviationAppConfig(AppConfig):
    name = 'aviation_app'
