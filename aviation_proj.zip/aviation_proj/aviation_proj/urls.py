from django.contrib import admin
from django.urls import path
from aviation_app.views import aviation_view, add_departure_item, delete_item, add_arrival_item, submit_feedback
from aviation_app import views
from . import settings
from django.contrib.staticfiles.urls import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    path('admin/', admin.site.urls), #for admin access
    path('', aviation_view), #shows current screen 
    path('add_departure_item/', add_departure_item), #allows user to submit departure airport
    path('add_arrival_item/', add_arrival_item), #allows user to submit arrival airport
    path('submit_feedback/', submit_feedback), #allows user to submit feeback
    path('delete_item/<int:item_id>/', delete_item), #allows for specific item to be removed from database
    path('showdepimage/', views.showdepimage, name='showdepimage'), #when departure image is to be shown
    path('showarrimage/', views.showarrimage, name='showarrimage'), #when arrival image is to be shown
]

urlpatterns += staticfiles_urlpatterns() #appends static folder information
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) #appends media (picture) folder information